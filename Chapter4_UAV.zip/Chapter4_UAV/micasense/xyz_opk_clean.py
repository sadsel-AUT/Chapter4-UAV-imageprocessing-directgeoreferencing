import math
import numpy as np
import micasense.xyz_opk_clean as xo
#P_wgs_nztm = arcpy.PointGeometry(arcpy.Point(Lon,Lat),arcpy.SpatialReference(4326)).projectAs(arcpy.SpatialReference(2193))
#PROJCS["NZGD2000 / New Zealand Transverse Mercator 2000",GEOGCS["NZGD2000",DATUM["New_Zealand_Geodetic_Datum_2000",SPHEROID["GRS 1980",6378137,298.257222101, AUTHORITY["EPSG","7019"]], TOWGS84[0,0,0,0,0,0,0], AUTHORITY["EPSG","6167"]], PRIMEM["Greenwich",0, AUTHORITY["EPSG","8901"]], UNIT["degree",0.0174532925199433, AUTHORITY["EPSG","9122"]], AUTHORITY["EPSG","4167"]], PROJECTION["Transverse_Mercator"], PARAMETER["latitude_of_origin",0], PARAMETER["central_meridian",173], PARAMETER["scale_factor",0.9996], PARAMETER["false_easting",1600000], PARAMETER["false_northing",10000000], UNIT["metre",1, AUTHORITY["EPSG","9001"]], AUTHORITY["EPSG","2193"]]
class Point:
    def __init__(self,X,Y,Z):
        self.X = X
        self.Y = Y
        self.Z = Z

    #"omega" - camera angle, in degrees
    # "phi" - camera angle, in degrees
    # "kappa" - camera angle, in degrees
    # "longitude">camera position
    # "latitude">camera position
    # "altitude">camera position
    # "altOverGround">average flight height, it is defined on flight planning stage
    # "CFL">camer focal length in mm
    # "FXP">focal x plane resolution in pixels/mm 
    # "FYP">focal y plane resolution in pixels/mm
    # "imageLengthpx">image length in pixels - 960 for rededge sensor
    # "imageWidthpx">image width in pixels - 1280 for rededge sensor


#for image in C:/Users/saselvar/Downloads/RockyReef_raw_rededge_1_5set/000/IMG_0121_1.tif

   
def CalculateParamsForWorldFile(yaw, omega, phi, kappa, altitude, NZTMX, NZTMY, CFL, imageLengthpx, imageWidthpx):
    
    #CFL = 5.5 #Camera focal length in mm
    sensorWidth = 4.8 #Width of sensor in mm
        
  
    groundPixSize = (float(sensorWidth) * float(altitude)) / (float(CFL) * float(imageWidthpx))
    print("ground pix size in meters = ", groundPixSize)

    #Calucating image length and width in meters
    imageLength = float(groundPixSize) * float(imageLengthpx)
    imageWidth = float(groundPixSize) * float(imageWidthpx)
    print("image size in meters = ",imageLength,imageWidth)
        #  converting angles from degrees to radian
    omega = np.deg2rad(float(omega))
    phi = np.deg2rad(float(phi))
    kappa = np.deg2rad(float(kappa))

    
    #  get image center (projected to groud) as offset to camera coordinates
    #  result of imageCenter is in image coordinate system
    imageCenter = GetImageCenter(omega, phi, kappa, float(altitude))
    print("Image Centre = ",imageCenter.X,imageCenter.Y,imageCenter.Z)

    #  calculating real image length for this height
    realImageLength = float(imageCenter.Z) * float(imageLength) / float(altitude)
    realImageWidth = float(imageCenter.Z) * float(imageWidth) / float(altitude)
    print("RealImg Length and Width in m =", realImageLength, realImageWidth)

    #  corners offset in image coordinates system
    xOffset = realImageWidth / 2
    yOffset = realImageLength / 2
    print("Corner offset X,Y = ", xOffset, yOffset)

    #  corners list
    imageCorners = [Point(xOffset, yOffset, imageCenter.Z),Point(-xOffset, yOffset, imageCenter.Z),Point(-xOffset, -yOffset, imageCenter.Z),Point(xOffset, -yOffset, imageCenter.Z)]
        
    projectionCorners = []

    for point in imageCorners:
        #  get image corner projected to the ground
        projectedPoint = GetProjectionCoordinates(yaw, omega, phi, kappa, altitude, point)

        projectionCorners.append(projectedPoint)


    #kappa_rotd = 270-kappa

    A = groundPixSize * math.cos(yaw)
    D = groundPixSize * math.sin(yaw) * -1
    B = D
    E = A * -1
    C = NZTMX+projectionCorners[3].X
    F = NZTMY+projectionCorners[3].Y
    
    return A, D, B, E, C, F        

def CalculateParamsForControlPoints(yaw, omega, phi, kappa, altitude, NZTMX, NZTMY, CFL, imageLengthpx, imageWidthpx):
    
    #CFL = 5.5 #Camera focal length in mm
    sensorWidth = 4.8 #Width of sensor in mm
        
  
    groundPixSize = (float(sensorWidth) * float(altitude)) / (float(CFL) * float(imageWidthpx)) #https://support.pix4d.com/hc/en-us/articles/202560249-TOOLS-GSD-calculator
    print("ground pix size in meters = ", groundPixSize)

    #Calucating image length and width in meters
    imageLength = float(groundPixSize) * float(imageLengthpx)
    imageWidth = float(groundPixSize) * float(imageWidthpx)
    print("image size in meters = ",imageLength,imageWidth)
        #  converting angles from degrees to radian
    omega = np.deg2rad(float(omega))
    phi = np.deg2rad(float(phi))
    kappa = np.deg2rad(float(kappa))

    
    #  get image center (projected to groud) as offset to camera coordinates
    #  result of imageCenter is in image coordinate system
    imageCenter = GetImageCenter(omega, phi, kappa, float(altitude))
    print("Image Centre = ",imageCenter.X,imageCenter.Y,imageCenter.Z)

    #  calculating real image length for this height
    realImageLength = float(imageCenter.Z) * float(imageLength) / float(altitude)
    realImageWidth = float(imageCenter.Z) * float(imageWidth) / float(altitude)
    print("RealImg Length and Width in m =", realImageLength, realImageWidth)

    #  corner offset in image coordinate system
    xOffset = realImageWidth / 2
    yOffset = realImageLength / 2
    print("Corner offset X,Y = ", xOffset, yOffset)

    #  corners list
    imageCorners = [Point(xOffset, yOffset, imageCenter.Z),Point(-xOffset, yOffset, imageCenter.Z),Point(-xOffset, -yOffset, imageCenter.Z),Point(xOffset, -yOffset, imageCenter.Z)]
        
    projectionCorners = []

    for point in imageCorners:
        #  get image corner projected to the ground
        projectedPoint = GetProjectionCoordinates(yaw, omega, phi, kappa, altitude, point)

        projectionCorners.append(projectedPoint)

    #NZTMX = 1793332.2052870842
    #NZTMY = 5924444.351318591

    P1 = ((NZTMX+projectionCorners[0].X),(NZTMY+projectionCorners[0].Y))
    P2 = ((NZTMX+projectionCorners[1].X),(NZTMY+projectionCorners[1].Y))
    P3 = ((NZTMX+projectionCorners[2].X),(NZTMY+projectionCorners[2].Y))
    P4 = ((NZTMX+projectionCorners[3].X),(NZTMY+projectionCorners[3].Y))
    #print("NZTM P1 = ", Point1)
    #print("NZTM P2 = ", Point2)
    #print("NZTM P3 = ", Point3)
    #print("NZTM P4 = ", Point4)

    return P1,P2,P3,P4
    
def GetProjectionCoordinates(yaw, omega, phi, kappa, altitude, imageCorner):
        #  converting point coordinates from image coordinate system to normal coordinate system
    imagePoint = ConvertImageCoordToNormal(yaw, omega, phi, kappa, imageCorner)

    x = altitude * imagePoint.X / imagePoint.Z
    y = altitude * imagePoint.Y / imagePoint.Z
        
    return Point(x, y, altitude)


def ConvertImageCoordToNormal(yaw, omega, phi, kappa, imageCorner):
        
    if yaw > 0:
        kappa = (math.pi / 2) - kappa
    else:
        kappa = kappa
        
    x1 = imageCorner.X * math.cos(kappa) + imageCorner.Y * math.sin(kappa)
    y1 = -imageCorner.X * math.sin(kappa) + imageCorner.Y * math.cos(kappa)
    z1 = imageCorner.Z

    x2 = x1 * math.cos(phi) - z1 * math.sin(phi)
    y2 = y1
    z2 = x1 * math.sin(phi) + z1 * math.cos(phi)

    x = x2
    y = y2 * math.cos(omega) + z2 * math.sin(omega)
    z = -y2 * math.sin(omega) + z2 * math.cos(omega)
    return Point(x, y, z)


def GetImageCenter(omega, phi, kappa, altitude):
    
    #  calculating coordinates of image center
    xCenter = altitude * math.tan(phi)
    yCenter = altitude * math.tan(omega)
    imageAltitude = altitude / (math.cos(omega) * math.cos(phi))

    #  recalculating center with kappa value
    alpha = math.atan(yCenter / xCenter) + kappa
    aa = math.sqrt(xCenter * xCenter + yCenter * yCenter)

    imageCenterX = math.cos(alpha) * aa
    imageCenterY = math.sin(alpha) * aa
    return Point(imageCenterX, imageCenterY, imageAltitude)

