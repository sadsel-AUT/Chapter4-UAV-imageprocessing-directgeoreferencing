import csv, os
import arcpy

inputFile = os.path.abspath('C:\imageprocessing-master\opkCalcRockyReef_green1_allDeg.csv')
outputFile = os.path.abspath('C:\imageprocessing-master\opkCalcRockyReef_green1_allDeg_nztm.csv')
print(inputFile)

with open(inputFile,'r') as f:
	data=list(csv.reader(f))
with open(outputFile,'w') as f1:
	writer=csv.writer(f1, delimiter=',',lineterminator='\n',)#\t
	writer.writerow(['Directory','Filename','Latitude','Longitude','NZTMX','NZTMY','Altitude','kappa','phi','omega','roll','pitch','yaw','kappI','phiI','omegaI','Iroll','Ipitch','Iyaw','CFL','imgWidthpx','imgHeightpx'])

	for i in range(1,len(data)):
		latitude = data[i][2]
		longitude = data[i][3]
        #ESPG:4236 is for wgs84, espg:2193 is for nztm
		P_wgs_nztm = arcpy.PointGeometry(arcpy.Point(longitude,latitude),arcpy.SpatialReference(4326)).projectAs(arcpy.SpatialReference(2193))
		nztmCent= str(P_wgs_nztm.centroid)
		centList = nztmCent.split(" ")
		nztmx = centList[0]
		nztmy = centList[1]

		row = [data[i][0],data[i][1],data[i][2],data[i][3],nztmx,nztmy,data[i][4],data[i][5],data[i][6],data[i][7],data[i][8],data[i][9],data[i][10],data[i][11],data[i][12],data[i][13],data[i][14],data[i][15],data[i][16],data[i][17],data[i][18],data[i][19]]
		writer.writerow(row)
        
        #header = "Directory,Filename,Latitude,Longitude,Altitude,kappa,phi,omega,roll,pitch,yaw,F35eql,CFL,imgWidthpx,imgHeightpx"
        #lines = [header]
