***** There are codes for 
	- reading the metadata of the file
	- reading the files and copying out GPS location as csv file (name the csv files relevant to the flight)
	- copying the metadata from original to processed data (access to metadata of processed file is not possible after copying over)

***** To execute the files the .txt files need to be renamed to 'exiftool.bat' and double clicked on.

***** Make sure the 'exiftool.exe' is in the same folder as the .bat file prior to execution